﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;

namespace RefApp.Shared
{
    public static class InstanceFactory
    {
        static IContainer container;
        static readonly ContainerBuilder builder;

        public static Dictionary<Type, Type> Registrations =
            new Dictionary<Type, Type>();

        static InstanceFactory()
        {
            builder = new ContainerBuilder();

            container = builder.Build();
        }

        public static void RegisterType<T1, T2>() where T2 : class,T1
        {
            Registrations[typeof(T1)] = typeof(T2);

            builder.RegisterType<T1>();

            container = builder.Build();
        }


        public static T GetInstance<T>()
        {
            return container.Resolve<T>();
        }
    }

}
