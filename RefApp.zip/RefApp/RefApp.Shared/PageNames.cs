﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefApp.Shared
{
    public class PageNames
    {
        public const string SomeOtherObjectsView = "RefApp.App.Views.SomeOtherObjectsView";
        public const string SomeObjectDetailView = "RefApp.App.Views.SomeObjectDetailView";
        public const string SomeOtherObjectDetailView = "RefApp.App.Views.SomeOtherObjectDetailView";
   }
}
