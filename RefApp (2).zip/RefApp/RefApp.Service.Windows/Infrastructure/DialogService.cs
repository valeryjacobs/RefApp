﻿using RefApp.Contracts.Services;
using RefApp.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;

namespace RefApp.Service.Windows.Infrastructure
{
    public class DialogService : IDialogService
    {

        public async void ShowDialog(string message)
        {
            MessageDialog messageDialog = new MessageDialog(message);
            await messageDialog.ShowAsync();
        }

        public async void ShowDeleteConfirmation()
        {
            MessageDialog messageDialog = new MessageDialog
                ("The item has been deleted");
            await messageDialog.ShowAsync();
        }

        public async void ShowAddToFavoriteConfirmation()
        {
            MessageDialog messageDialog = new MessageDialog
                ("This travel is now added to your favorites!");
            messageDialog.Commands.Add(new UICommand("OK, thanks!"));
            messageDialog.Commands.Add(new UICommand("Undo please"));
            await messageDialog.ShowAsync();
        }

        public async void ShowPushNotificationQuestion()
        {
            MessageDialog messageDialog = new MessageDialog
                ("Enable push notifications?");
            messageDialog.Commands.Add(new UICommand("Yes!", OnYesClicked));
            messageDialog.Commands.Add(new UICommand("No!", OnNoClicked));
            await messageDialog.ShowAsync();
        }

        private void OnNoClicked(IUICommand command)
        {

        }

        private void OnYesClicked(IUICommand command)
        {
            var toastService =
                InstanceFactory.GetInstance<IPushNotificationService>();
            toastService.RegisterChannelUriWithService();
        }
    }
   
}
